<?php
session_start();
require "conexionBaseDatos.php";
extract ($_REQUEST);
$pass=md5($_REQUEST['ContraseñaEs']);

$Conexion=Conectarse();
/* Vamos a realizar el proceso para consultar los usuarios con la condicíon
dada por los valores ingresados en el login y password*/
	
	$sql= "select * from seguridad where correo_instituicional = '$_REQUEST[LoginEs]' and contrasena = '$pass'";
	//Asignar a una variable el resultado de la consulta
	$resultado=$Conexion->query($sql);
	while($usuario = $resultado->fetch_object()){
		$id_documento = $usuario->id_documento;
	}
	$sql1= "SELECT nombre_materia from materia where id_materia in(select id_materia from asignacion_materia_curso where id_documento ='$id_documento')";
    $resultado1 = $Conexion->query($sql1);


	//while($usuario = $resultado->fetch_object()){
	//	$id_documento = $usuario->id_documento;    
	//	header("location:../vista/gestionar_asistencia_estudiante21.php?IdEstudiante=$id_documento");

	//}

//verifico si existe el usuario
	$existe = $resultado->num_rows;

	if ($existe==1)  //quiere decir que los datos estan bien
	{
	$usuario=$resultado->fetch_object();
	//Registramos una variable de sesión llamada user
	$_SESSION['user']= $usuario->usuLogin;	
	?>
	<h2 style= "COLOR=">Curso 601</h2>
    <form id="rolForm">
	<div class="form-group">
	<label for="rolSelect">Seleccionar Materia</label>
	<select class="form-control" id="rolSelect" name="materias">
		<option value="0">Seleccione</option>
		<?php
		while($cargo = $resultado1->fetch_object()){
		 ?>
		<option value="<?php echo $cargo->id_materia?>"><?php echo $cargo->nombre_materia?></option>                              
		</select>
		</div>
		<?php
		header("location: ../vista/gestionar_asistencia_estudiante21.php");	
		}
	}
else
{
	header("location:../vista/iniciar_sesion11.php");  //x=1, quiere decir que el usuario no esta registrado
}

?>
