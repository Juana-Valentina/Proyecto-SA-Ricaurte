<?php
    function Conectarse()
    {
    $conexion= new mysqli("localhost","root","", "proyecto_ricaurte3"); 
        if($conexion->connect_errno)
        {
            echo"Error conexion a la puta base de datos" . $conexion->connect_error;
            exit();
        }
        else{
            echo"Conectados satisfactoriamente caballero " ;
        }
    }
?>