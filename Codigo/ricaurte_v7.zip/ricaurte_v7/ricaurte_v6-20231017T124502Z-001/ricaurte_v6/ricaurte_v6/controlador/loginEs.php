<?php
    session_start();
    require("conexionBaseDatos.php");
    extract($_REQUEST);

    $Contraseña = md5($_REQUEST['Contraseña']);
    $login = $_REQUEST['LoginEs'];

    $conexion=Conectarse();

    $sql="SELECT * FROM `seguridad` where Usuario = '$login' and contraseña = '$Contraseña'";

    $resultado = $conexion->query($sql);

    $Existe = $Resultado->num_rows;
    if($Existe== 1){
        header("location: ../vista/gestionar_asistencia_estudiante21.php");
    }
?>