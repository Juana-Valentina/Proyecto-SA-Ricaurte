<?php
    extract ($_REQUEST);

    require("conexionBaseDatos.php");
    
    $Encriptacion = md5($_REQUEST['Contraseña']);

    $sql = "INSERT INTO `persona/registro`(Documento, Nombre, Telefono) VALUES ('$_REQUEST[Documento]','$_REQUEST[Nombre]','$_REQUEST[Telefono]')";
    $sql1 = "INSERT INTO `seguridad`(Usuario, contraseña, IdDocumento) VALUES ('$_REQUEST[Correo_institucional]','$Encriptacion','$_REQUEST[Documento]')";
    if($conexion->query($sql)){
        header("location: ../vista/confirmar_correo_institucional.php"); 
    }
    else{
        header("location: ../vista/iniciar_sesion_administradores12.php "); 
    }
    if($conexion->query($sql1)){
        header("location: ../vista/confirmar_correo_institucional.php"); 
    }
    else{
        header("location: ../vista/iniciar_sesion_administradores12.php"); 
    }
?>