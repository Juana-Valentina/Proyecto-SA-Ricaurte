<?php
    extract ($_REQUEST);

    require("conexionBaseDatos.php");
    
    $sql = "INSERT INTO `persona/registro`(Documento, Nombre, Telefono) VALUES ('$_REQUEST[DocumentoAd]','$_REQUEST[NombreAd]','$_REQUEST[NumeroAd]')";
    $sql1 = "INSERT INTO `seguridad`(Usuario, contraseña, IdDocumento) VALUES ('$_REQUEST[Correo_institucionalAd]','$_REQUEST[ContraseñaAd]','$_REQUEST[DocumentoAd]')";
    if($conexion->query($sql)){
        header("location: ../vista/confirmar_correo_institucional.php"); 
    }
    else{
        header("location: ../vista/iniciar_sesion_administradores12.php"); 

    }
    if($conexion->query($sql1)){
        header("location: ../vista/confirmar_correo_institucional.php"); 
    }
    else{
        header("location: ../vista/iniciar_sesion_administradores12.php"); 

    }
?>