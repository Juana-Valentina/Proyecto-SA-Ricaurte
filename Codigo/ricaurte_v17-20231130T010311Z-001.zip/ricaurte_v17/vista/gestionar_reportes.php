<?php
  require("../controlador/conexionBaseDatos.php");
  require("../controlador/administrativo.php");

  extract ($_REQUEST);

  $objConexion = Conectarse();

  $documento = $_REQUEST['Identificacion'];

  $consulta="SELECT nombre_materia, nombre_curso, materia.id_materia FROM asignacion_materia_curso, materia WHERE asignacion_materia_curso.id_materia = materia.id_materia AND id_documento = '$documento'";

  $resultado=$objConexion->query($consulta);

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestionar reportes 2.5</title>
<!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap/dist/css/bootstrap.min.css">
<!-- Archivo CSS  -->
  <link rel="stylesheet" href="CSS/gestionar_reportes.css">
  
</head>

<header class="menu">
        <div id="container2">
        <nav class="navbar navbar-expand-lg navbar-gray light bg-gray light">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active">
            <a class="nav-link" href="../controlador/controlador.php?accion=iniciar_sesion">Inicio </a>
            </li>
            <li class="nav-item active">
            <a class="nav-link" href="perfil.php?Identificacion=<?php echo $documento ?>">Perfil</a>
            </li>
            <li class="nav-item active">
            <a class="nav-link" href="../controlador/controlador.php?accion=salir">Salir</a>
            </li>
        </ul>
    </div>
    </nav>
            <link rel="stylesheet" href="CSS/header_ricaurte.css">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            </div>
</header>

<body class="background">
  <div class="container mt-5 content">
    <h1>Gestionar Reportes</h1>
    <hr>
<!-- Agregar Profesor -->
  <div class="card">
    FILTROS
  <div class="card-body">
    <form id="formAgregarProfesor">
        <form id="rolForm">
            <div class="form-group">
                <input type="date">           
            </div>
        </form>
<BR>
        <form id="rolForm">
            <div class="form-group">
                <label for="rolSelect">SELECCIONE CURSOS:</label>
                <select class="form-control" id="rolSelect">
                    <option value="profesor">SELECCIONAR CURSOS</option>
                    <option value="601">601</option>
                    <option value="701">701</option>
                    <option value="802">802</option>
                    <option value="901">901</option>
                    <option value="1001">1001</option>
                    <option value="1101">1101 </option>
                </select>
            </div>
        </form>
        <BR>
        <form id="rolForm">
            <div class="form-group">
                <label for="rolSelect">SELECCIONE MATERIAS:</label>
                <select class="form-control" id="rolSelect">
                    <option value="profesor">SELECCIONE MATERIAS</option>
                    <option value="Español">Español</option>
                    <option value="Ingles">Ingles</option>
                    <option value="Matematicas">Matematicas</option>
                    <option value="Filosofia">Filosofia</option>
                    <option value="Quimica">Quimica</option>
                    <option value="Estadistica">estadistica</option>
                </select>
            </div>
        </form>
</form>
</div>
</div>
<!-- Lista de Profesores -->
  <div class="mt-4">
    <h3 style="color: #FF007A;">REPORTES</h3>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th STY>CURSOS</th>
          <th>MATERIAS</th>
          <th>FECHA</th>
          <th>INGRESAR</th>
        </tr>
        <tr>
            <th>601</th>
            <th>Español</th>
            <th>2023/04/31</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>702</th>
            <th>Ingles</th>
            <th>2022/11/20</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>703</th>
            <th>Quimica</th>
            <th>2023/04/31</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>901</th>
            <th>Algebra</th>
            <th>2022/07/16</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>603</th>
            <th>Sociales</th>
            <th>2023/02/10</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>1101</th>
            <th>Biologia</th>
            <th>2021/06/20</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>603</th>
            <th>Ingles</th>
            <th>2023/12/05</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>1103</th>
            <th>Matematicas</th>
            <th>2022/03/19</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>903</th>
            <th>Calculo</th>
            <th>2020/08/23</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
          <tr>
            <th>801</th>
            <th>Educacion fisica</th>
            <th>2024/10/10</th>
            <th><a href="../controlador/controlador.php?accion=confirmar_correo">Boton</a></th>
          </tr>
      </thead>
      <tbody id="listaProfesores">
<!-- Aquí se cargarán los profesores -->
</tbody>
</table>
</div>
</div>
<!-- Bootstrap JS y jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap/dist/js/bootstrap.min.js"></script>
  <!--  JavaScript  -->
  <script src="vista/JAVASCRIPT/horario_profes_a_cursos35.js"></script>
</body>
</html>

