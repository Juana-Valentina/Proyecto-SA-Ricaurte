<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Horarios de Estudiantes</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap/dist/css/bootstrap.min.css">
    <!--  archivo CSS  -->
    <link rel="stylesheet" href="CSS/subir_materias_a_cursos34.css">
</head>
<body class="background">
    <div class="container mt-5 content">
        <h1>Subir materias</h1>
        <hr>
<!-- Agregar Materia -->
    <div class="card mt-4">
    <div class="card-header">
        Agregar Materia 
    </div>
    <div class="card-body">
        <form id="formAgregarMateria" METHOD= "POST" action="../controlador/agregarArchivos.php">
    <div class="form-group">
        <label for="nombreMateria">Nombre de la Materia</label>
        <input type="text" class="form-control" id="nombreMateriai" name="nombreMateria" placeholder="Nombre de la Materia">
    </div>
        <button type="submit" class="btn btn-custom">Agregar Materia</button>
    </form>
</div>
</div>
<!-- Lista de Materias -->
    <div class="mt-4">
        <h2>Materias</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Materia</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody id="listaMaterias">
<!-- Aquí se cargarán las materias -->
                <tr>
                    <td>Matemáticas</td>
                    <td><button class="btn btn-primary">Editar</button></td>
                    <td><button class="btn btn-danger">Eliminar</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<div class="text-center mt-3">
    <button class="btn btn-primary" id="btnGuardar">Guardar</button>
    <a href="../controlador/controlador.php?accion=regresar_elegir" class="btn btn-danger" id="cancelarBtn">Regresar</a>
</div>
<!-- Bootstrap JS y jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Tu archivo JavaScript personalizado -->
    <script src="vista/JAVASCRIPT/subir_materias_a_cursos34.js"></script>
</body>
</html>